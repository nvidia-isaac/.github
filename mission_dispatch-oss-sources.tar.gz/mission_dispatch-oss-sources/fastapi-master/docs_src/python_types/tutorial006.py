from typing import List


def process_items(items: List[str]):
    for item in items:
        print(item)
